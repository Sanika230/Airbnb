import React from 'react'

function Profile() {
  return (
    <div>
      <h1 className='page-header'> Profile</h1>
    </div>
  )
}

export default Profile
