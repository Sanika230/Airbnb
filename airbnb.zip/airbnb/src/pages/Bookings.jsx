import React from 'react'

function Bookings() {
  return (
    <div>
      <h1 className='page-header'>Bookings</h1>
    </div>
  )
}

export default Bookings
